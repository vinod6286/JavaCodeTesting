/**
 * 
 */
package com.java.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

public class JUnitAppilication {

	private Set<Integer> setA;
	private List<Integer> setB;

	public static void main(String[] args) {
		JUnitAppilication JUnitAppilication = new JUnitAppilication();
		JUnitAppilication.higestNumber();

	}

	@Before
	public void setUp() {
		setA = new HashSet<Integer>();

		setA.add(100);
		setA.add(200);
		setA.add(300);
		setA.add(400);
		setA.add(100);
		setA.add(600);
		setA.add(300);
		setB = new ArrayList<Integer>();
		setB.add(100);
		setB.add(200);
		setB.add(300);
		setB.add(400);
		setB.add(100);
		setB.add(600);
		setB.add(300);
	}

	@Test
	public void second() {
		JUnitAppilication JUnitAppilication = new JUnitAppilication();
		assertEquals(setA, JUnitAppilication.findDuplicates(setB));
	}

	@Test
	public void first() {
		JUnitAppilication JUnitAppilication = new JUnitAppilication();
		assertEquals("100", JUnitAppilication.higestNumber());
		
	}

	@Test

	public void third() {
		JUnitAppilication JUnitAppilication = new JUnitAppilication();
		JUnitAppilication.duplicateElements();
		// assertEquals("100",JUnitAppilication.duplicateElements());
	}

	public void duplicateElements() {
		int[] my_array = { 1, 2, 5, 5, 6, 6, 7, 2 };

		for (int i = 0; i < my_array.length - 1; i++) {
			for (int j = i + 1; j < my_array.length; j++) {
				if ((my_array[i] == my_array[j]) && (i != j)) {
					System.out.println("Duplicate Element : " + my_array[j]);
				}
			}
		}
	}

	public String higestNumber() {
		Random r = new Random();
		// Create array of 1000 ints
		int[] intArr = new int[1000];

		// Fill array with random ints
		for (int i = 0; i < intArr.length; i++) {
			intArr[i] = r.nextInt();
		}
		System.out.println(intArr.length);

		// int n[] = {1,5,7,3};
		for (int i = 0; i < intArr.length; i++) {
			if (intArr[i] > intArr[0]) {
				intArr[0] = intArr[i];
			}
		}
		System.out.println(intArr[0]);
		return "" + intArr[0];
	}

	public Set<Integer> findDuplicates(List<Integer> input) {
		List<Integer> copy = new ArrayList<Integer>(input);
		for (Integer value : new HashSet<Integer>(input)) {
			copy.remove(value);
		}
		return new HashSet<Integer>(copy);
	}

}
