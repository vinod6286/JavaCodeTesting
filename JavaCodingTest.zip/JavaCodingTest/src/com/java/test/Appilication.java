package com.java.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Appilication {

	public static void main(String[] args) throws IOException {
		File file = new File("d:\\sample.txt");

		BufferedReader br = new BufferedReader(new FileReader(file));
		String reverseWord = "";
		String st;
		FileWriter fw = new FileWriter("d:/output.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		while ((st = br.readLine()) != null) {
			System.out.println(st);
			

			String[] words = st.split("\\s+");

			for (String word : words) {
				System.out.println(word);
				reverseWord = word + " " + reverseWord;
			}
			bw.write(reverseWord + "\r\n");

			reverseWord = "";

		}
		bw.close();
		br.close();
	}

}
